/*
===============================================================================
 Name        : main.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#if defined (__USE_LPCOPEN)
#if defined(NO_BOARD_LIB)
#include "chip.h"
#else
#include "board.h"
#endif
#endif

#include <cr_section_macros.h>

#include "SPI_ADC.h"
#include "DigitalIoPin.h"

extern "C" {
#include "Yin.h"
#include "notes.h"
}


static int16_t ar[NUM_SAMPLES];
static int ar_index = 0;
static bool semBool = 0;
volatile uint32_t RIT_count;

SPI_ADC* myspiv2;

extern "C" {
void RIT_IRQHandler(void) {

	myspiv2->InitiateConversion();

	if (--RIT_count == 0) {
		Chip_RIT_Disable(LPC_RITIMER); // disable timer
		semBool = 1;
	}

	Chip_RIT_ClearIntStatus(LPC_RITIMER); // clear IRQ flag

}
void SPI0_IRQHandler(void) {
	uint16_t adc_sample = myspiv2->ReadSample();
	//ar[ar_index] = adc_sample - 1638;
	ar[ar_index] = adc_sample - 2048;
	//ar[ar_index] = adc_sample;
	ar_index++;
}
}

void RIT_start(uint32_t count, uint32_t us) {
	uint64_t cmp_value;

	semBool = 0;
	ar_index = 0;

	// Determine approximate compare value based on clock rate and passed interval
	cmp_value = (uint64_t) Chip_Clock_GetSystemClockRate() * (uint64_t) us / 1000000;

	// disable timer during configuration
	Chip_RIT_Disable(LPC_RITIMER);

	RIT_count = count;
	// enable automatic clear on when compare value==timer value
	// this makes interrupts trigger periodically
	Chip_RIT_EnableCompClear(LPC_RITIMER);
	// reset the counter
	Chip_RIT_SetCounter(LPC_RITIMER, 0);
	Chip_RIT_SetCompareValue(LPC_RITIMER, cmp_value);
	// start counting
	Chip_RIT_Enable(LPC_RITIMER);
	// Enable the interrupt signal in NVIC (the interrupt controller)
	NVIC_EnableIRQ(RITIMER_IRQn);

	// wait for ISR to tell that we're done
	while(semBool == 0) {
		// Disable the interrupt signal in NVIC (the interrupt controller)
	}

	NVIC_DisableIRQ(RITIMER_IRQn);
}

int main(void) {

#if defined (__USE_LPCOPEN)
    SystemCoreClockUpdate();
#if !defined(NO_BOARD_LIB)
    Board_Init();
#endif
#endif

	Chip_RIT_Init(LPC_RITIMER);				// initialize RIT (= enable clocking etc.)
	NVIC_SetPriority( RITIMER_IRQn, 5 );	// set the priority level of the interrupt


	myspiv2 = new SPI_ADC();

	Yin yin;
	float pitch; // Detected pitch
//	char* notename; // Name of note closest to detected pitch
//	float refval; // Reference frequency of note closest to detected pitch
//	float diff;  // How flat (positive diff) or sharp (negative diff) the signal is

	Yin_init(&yin, NUM_SAMPLES, YIN_DEFAULT_THRESHOLD); // 95% accuracy setting with NUM_SAMPLES samples

    while(1) {
    	RIT_start(NUM_SAMPLES, 50);

    	pitch = Yin_getPitch(&yin, ar);
    	if (pitch > -1.0) {
        	//notename = getNote(pitch);
        	//refval = lookupNote(notename);
        	//diff = refval - pitch;
//        	if (diff < 0.2 && diff > -0.2) {
//        		diff = 0;
//        	}

        	/* PRINTING FOR TESTING
        	if (diff < 0) {
        		printf("%.2f Hz %s (%.2f) Sharp %.2f\r\n", pitch, notename, refval, diff);
        	} else if (diff > 0){
        		printf("%.2f Hz %s (%.2f) Flat %.2f\r\n", pitch, notename, refval, diff);
        	} else {
        		printf("%.2f Hz %s (%.2f) OK %.2f\r\n", pitch, notename, refval, diff);
        	}
        	*/
    	}
    }

    return 0 ;
}
